import modal

app = modal.App(name="cnn-dog-cat-classifier")

image = modal.Image.debian_slim(python_version="3.10").pip_install(
    "numpy",
    "matplotlib" ,
    "tensorflow",
    "pillow"
)

volume = modal.Volume.from_name(
    "cat-dog-data"
)
MODEL_DIR = "/data"

@app.function(
    volumes={MODEL_DIR: volume},
    image=image,
)

def train_model():
    import os
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
    from tensorflow.keras.preprocessing.image import ImageDataGenerator

    DATA_DIR = "/data/data"
    print(f"Data directory: {DATA_DIR}")


    if not os.path.exists(DATA_DIR):
        raise ValueError(f"Data directory '{DATA_DIR}' does not exist!")

    train_dir = os.path.join(DATA_DIR, "train")
    val_dir = os.path.join(DATA_DIR, "val")

    train_datagen = ImageDataGenerator(rescale=1.0 / 255)
    val_datagen = ImageDataGenerator(rescale=1.0 / 255)

    train_generator = train_datagen.flow_from_directory(
        train_dir,
        target_size=(150, 150),
        batch_size=32,
        class_mode="binary"
    )

    validation_generator = val_datagen.flow_from_directory(
        val_dir,
        target_size=(150, 150),
        batch_size=32,
        class_mode="binary"
    )

    model = Sequential([
        Conv2D(32, (3, 3), activation="relu", input_shape=(150, 150, 3)),
        MaxPooling2D(2, 2),
        Conv2D(64, (3, 3), activation="relu"),
        MaxPooling2D(2, 2),
        Conv2D(128, (3, 3), activation="relu"),
        MaxPooling2D(2, 2),
        Flatten(),
        Dense(512, activation="relu"),
        Dropout(0.5),
        Dense(1, activation="sigmoid")
    ])

    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

    history = model.fit(
        train_generator,
        validation_data=validation_generator,
        epochs=5
    )

    model_save_path = os.path.join(DATA_DIR, "cat_dog_classifier.keras")
    model.save(model_save_path, save_format="keras")
    print(f"Model trained and saved as '{model_save_path}'")

    final_train_acc = history.history["accuracy"][-1]
    final_val_acc = history.history["val_accuracy"][-1]
    print(f"Final Training Accuracy: {final_train_acc:.4f}")
    print(f"Final Validation Accuracy: {final_val_acc:.4f}")


@app.local_entrypoint()
def main():
    print("Starting model training on Modal...")
    train_model.remote()

